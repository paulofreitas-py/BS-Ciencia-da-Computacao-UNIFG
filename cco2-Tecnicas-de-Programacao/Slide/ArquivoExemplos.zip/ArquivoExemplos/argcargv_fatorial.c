#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int fatorial(int n) {
	int i, fat = 1;
	for (i = n; i > 1; i--) {
		//fat = fat * i;
		fat *= i;
	}
	return fat;
}

int main(int argc, char *argv[]) {
	int num;
	
	if (argc == 2) {
		num = atoi(argv[1]);
		printf("O fatorial de %d! = %d\n", num, fatorial(num));
	} else {
		printf("Argumento nao informado...\n");
		printf("Digite um numero: ");
		scanf("%d", &num);
		printf("\nO fatorial de %d! = %d", num, fatorial(num));
	}
	return 0;
}
