#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

// fun��o que calcula a m�dia de dois n�meros
float media(float a, float b) {
	return (a + b) / 2;
}

int main(int argc, char *argv[]) {
	// vari�vel de controle do loop
	int i;
	// duas vari�veis que recebem os dois n�meros vindos do terminal
	float n1, n2;
	
	// imprime a quantidade de argumentos passados pelo terminal
	printf("Quantidade de argumentos recebidos: %d\n", argc);
	
	// imprime cada argumento passado pelo terminal
	// no argv[0] temos o nome do programa
	printf("\nImprimindo os argumentos...");
	for(i = 0; i < argc; i++) {
		printf("\n%s", argv[i]);
	}
	
	// verifica se o usu�rio digitou dois argumentos
	if (argc == 3) {
		// converte string para float
		n1 = atof(argv[1]);
		n2 = atof(argv[2]);
		// calcula a m�dia de n1 e n2
		printf("\n\nA media e: %.1f", media(n1, n2));
	}
	
	return 0;
}
